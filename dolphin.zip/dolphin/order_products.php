<?php include 'link_header.php'?>
<?php include 'header.php'?>

  <style>
    .btn{
      background: #e06b09;
      color: white;
    }
    
  </style>
 <body>
  <br>
  <br>
  <aside>
<div class="container ">
  <div class="row">
    <div class="col-md-4">
      <div>
        <img src="images/c1.jpg" style="width: 100%;">
      </div>
    </div>
    <div class="col -col-md-6" style="font-family: sans-serif;">
      <div>
        <h1 style="color: #e06b09">90 mm PN 8 HDPE Pipe</h1>
        <p>HDPE AND MDPE PIPES</p>
        <h4><b>HDPE Drinking Water Pipes</b></h4>
      </div>
      <div>
        <p>We are leading and certified manufacturer of HDPE pipe with all sizes</p>
      </div>
      <div>
        <!-- Button trigger modal -->
<button type="button" class="btn" data-toggle="modal" data-target="#exampleModalLong">
  Ask for Qutes
</button>

<!-- Modal -->
<div class="modal fade" id="exampleModalLong" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title centre" id="exampleModalLongTitle">  Ask for Qutes</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form>
          <p style="
    color: #a58a8a;
    font-size: 13px;
">Provide us your contact detail and our sales team will get in touch with you within 24 hrs</p>
          <div class="form-group">
    <label for="inputname">Name</label>
    <input type="text" class="form-control" id="inputname" placeholder="name">
  </div>
          <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputPhone1">phone</label>
      <input type="number" class="form-control" id="inputPhone1" placeholder="+91">
    </div>
    <div class="form-group col-md-6">
      <label for="inputAddress">Address</label>
      <input type="text" class="form-control" id="inputAddress" placeholder="Address">
    </div>
  </div>
  
        </form>
      </div>
      <div class="modal-footer">
        <!--<button type="button" class="btn btn-secondary" data-check="modal">check box</button>-->
        <button type="button" class="btn btn-primary">Send</button>
      </div>
    </div>
  </div>
</div>
      </div>
    </div>
    
    <div class=" col-md-2" style="text-align: end;">
    <div>
      <h4 ><del>₹-234</del></h4>
      <h3 style="color: #e06b09;">₹ 345</h3>
    </div>
    </div>
  </div>
</div>
</aside>
<br>
<br>
<section>
  <div class="container">
  <ul class="nav nav-tabs" style="font-size: 19px; ">
  <li class="nav-item">
    <a class="nav-link active" href="#" style="border-bottom:2px; border-color: #e06b09;" >DESCRIPTION</a>
  </li>
</ul>
<br>
<br>
<div>
  <h2>Features :-</h2>
  <ol>
    <li>Manufactured from virgin pipe grade raw materials (PE80, PE100).</li>
    <li>Excellent corrosion and chemical resistance. ...</li>
    <li>High flow characteristics.</li>
    <li>Light in Weight.</li>
    <li>Easy to handle & transport.</li>
    <li>Excellent flexibility combined with strength.</li>
    <li>Good abrasion resistance.</li>
  </ol>
  </div>
  <br>
  <br>
  <div>
    <h2>Specification:-</h2>
    <ul>
      <ol>Packaging Form - Roll.</ol>
      <ol>Appication - for driniking water..</ol>
    </ul>
  </div>


</div>
</section>


<?php include 'foooter.php' ?>


