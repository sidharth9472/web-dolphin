<?php
$hostname = "http://localhost/php/dolphin/";

$conn = mysqli_connect("localhost","root","","dolphinwatersolution") or die("Connection failed : " . mysqli_connect_error());

?>
