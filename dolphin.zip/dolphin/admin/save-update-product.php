 <?php
        if(isset($_POST["submit"])) {
      include "config.php";
     $file_name = $_FILES["p_fileToUpload"]["name"];
     $old_image = $_POST["old_p_fileToUpload"];
      
      // About Old Image 1
      if($file_name != ''){
        $new_fileToUpload = $_FILES["p_fileToUpload"]["name"];
      }else{
          $new_fileToUpload =  $old_image;
      }
      $target_dir = "upload/product/";
      $target_file = $target_dir . basename($new_fileToUpload);
      move_uploaded_file($_FILES["p_fileToUpload"]["tmp_name"], $target_file);

   
    /* query for update category table */
    $sql1 = "UPDATE product_details SET product_name='{$_POST['p_name']}',tittle='{$_POST['p_tittle']}',sub_tittle='{$_POST['p_sub_tittle']}',short_details='{$_POST['p_short_details']}',description='{$_POST['p_desc']}',short_description='{$_POST['p_short_desc']}',price='{$_POST['p_price']}',current_price='{$_POST['p_current_price']}',image='{$target_file}'  WHERE  id='{$_POST['up_id']}'";
    

      if (mysqli_query($conn,$sql1)){
      // redirect all category page 
      header("location: {$hostname}/admin/product.php");
      }
    }

  ?>
