<?php
$hostname = "http://dolphinwatersolutions.in/";

$conn = mysqli_connect("localhost","root","","dolphinwatersolution") or die("Connection failed : " . mysqli_connect_error());

?>
