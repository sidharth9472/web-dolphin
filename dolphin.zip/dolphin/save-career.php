<?php
   if(isset($_POST['submit'])){
      include "config.php";

    $file_name = $_FILES['fileToUpload']['name'];
    $file_size = $_FILES['fileToUpload']['size'];
    $file_tmp = $_FILES['fileToUpload']['tmp_name'];
    $file_type = $_FILES['fileToUpload']['type'];
    $file_error = $_FILES['fileToUpload']['error'];
    $file_ext = pathinfo($file_name,PATHINFO_EXTENSION);
    $file_ext_lc =strtolower($file_ext);
    $extensions = array("jpeg","jpg","png","pdf","docx");
  }
    if(in_array($file_ext_lc,$extensions) === false)
    {
      $errors[] = "This extension file not allowed, Please choose a PDf or PNG file.";
    }

    if($file_size > 2097152){
      $errors[] = "File size must be 2mb or lower.";
    }
    $new_name = uniqid("FILE-",true).'.'.$file_ext_lc;
    $target = "uploads/".$new_name;

    if(empty($errors) == true){
      move_uploaded_file($file_tmp,$target);
    }else{
     print_r($errors);
      die();
    }
   
  $name = mysqli_real_escape_string($conn, $_POST['name']);
  $phone = mysqli_real_escape_string($conn, $_POST['phone']);
  $email = mysqli_real_escape_string($conn, $_POST['email']);
  $designation = mysqli_real_escape_string($conn, $_POST['designation']);
 
 

  $sql = "INSERT INTO career(`name`,`phone_no`,`email`,`designation`,`image`) VALUES ('{$name}','{$phone}','{$email}','{$designation}','{$file_name}')";
   
   
   if(mysqli_query($conn, $sql)){
    header("Location:{$hostname}/career.php");
     echo "<div class='alert alert-danger'>Submitted.</div>";
  }else{
     echo "<div class='alert alert-danger'>Query Failed.</div>";
  }
   
?>
